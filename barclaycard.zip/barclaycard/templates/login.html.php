<div class="login-container">
        <div class="wrapper animated bounceInLeft">
            
            <div class="contact">
               
                <form>
                    <p>
                        <label>Email-Address</label>
                        <input type="email" name="email" required>
                    </p>
                    <p>
                  
                        <label>Password</label>
                        <input type="password" name="pass">
                    </p>
                    <p>
                    <p class="full">
                        <button type="submit" name = "submit" >Submit</button>
                    </p>
                </form>
            </div>

        </div>
    </div>

