
					<h1 style="text-align:center;">Add Product</h1>
						
<div class="login-container">
        <div class="wrapper animated bounceInLeft">
            <div class="company-info">
                <h3>Sherlock Comb</h3>
                <ul>
                    <li><i class="fa fa-road"></i>44 Something St</li>
                    <li><i class="fa fa-phone"></i>555-555-5555</li>
                    <li><i class="fa fa-envelope"></i>sherlock@test.com</li>
                </ul>
            </div>
            <div class="contact">
               
                <form method="POST" action="">
                    <p>
                        <label>Product Name</label>
                        <input type="text" name="productname" required>
                    </p>
					<p>
                        <label>Price</label>
                        <input type="text" name="productprice" required>
                    </p>
					<p>
                        <label>Description</label>
						<textarea name="des" id="" cols="20" rows="10"></textarea>
                    </p>
                    <p>
                    <p class="full">
                        <button type="submit" name = "submit" >Submit</button>
                    </p>
                </form>
            </div>

        </div>
    </div>


