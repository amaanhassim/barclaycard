<?php
$pdo2 = new PDO('mysql:dbname=barclaycard;host=127.0.0.1', 'student', 'student', [PDO::ATTR_ERRMODE =>  PDO::ERRMODE_EXCEPTION ]);
?>