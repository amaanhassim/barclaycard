<?php


require '../../functions/loadtemplate.php';

$content = loadtemplate('../../templates/addservice.html.php',[]);

require '../../templates/layout.html.php';