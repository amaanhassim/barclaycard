<?php
require '../functions/loadtemplate.php';

$content = loadtemplate('../templates/sampleform.html.php',[]);

require '../templates/layout.html.php';

?>