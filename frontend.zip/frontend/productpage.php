<?php

require '../functions/loadtemplate.php';

$content = loadtemplate('../templates/productpage.html.php', []);

require '../templates/layout.html.php';
?>